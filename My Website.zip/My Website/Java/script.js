document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("game-over").style.display = "none";
  document.getElementById("start-game").style.display = "block";

  // 返回顶部按钮
  const backToTopBtn = document.getElementById("back-to-top");
  window.addEventListener("scroll", function () {
    backToTopBtn.style.display = window.scrollY > 300 ? "block" : "none";
  });
  backToTopBtn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  // 导航滚动
  const navLinks = document.querySelectorAll("nav a");
  navLinks.forEach(link => {
    link.addEventListener("click", function (event) {
      event.preventDefault();
      const targetName = this.getAttribute("data-target");
      const targetSection = document.querySelector(`[data-section="${targetName}"]`);
      if (targetSection) fastScrollTo(targetSection.offsetTop, 500);
    });
  });
  function fastScrollTo(targetPosition, duration) {
    const startPosition = document.documentElement.scrollTop || document.body.scrollTop;
    const distance = targetPosition - startPosition;
    let startTime = null;
    function animationStep(currentTime) {
      if (!startTime) startTime = currentTime;
      const elapsedTime = currentTime - startTime;
      const progress = Math.min(elapsedTime / duration, 1);
      document.documentElement.scrollTop = startPosition + distance * progress;
      document.body.scrollTop = startPosition + distance * progress;
      if (elapsedTime < duration) requestAnimationFrame(animationStep);
    }
    requestAnimationFrame(animationStep);
  }
  if ("scrollRestoration" in history) {
    history.scrollRestoration = "manual";
  }
  window.scrollTo(0, 0);

  const startGameBtn = document.getElementById("start-game");
  if (startGameBtn) {
    startGameBtn.style.visibility = "visible";
    startGameBtn.disabled = false;
  }

  // Character Slider
  let currentIndex = 0;
  const slides = document.querySelectorAll(".character-card");
  const totalSlides = slides.length;
  const sliderContainer = document.querySelector(".character-container");
  const prevButton = document.getElementById("char-prev");
  const nextButton = document.getElementById("char-next");
  let autoSlideTimer;
  window.moveSlide = function (direction) {
    currentIndex += direction;
    if (currentIndex >= totalSlides) currentIndex = 0;
    else if (currentIndex < 0) currentIndex = totalSlides - 1;
    sliderContainer.style.transform = `translateX(${-currentIndex * 100}%)`;
    resetAutoSlide();
  };
  function resetAutoSlide() {
    clearInterval(autoSlideTimer);
    autoSlideTimer = setInterval(() => moveSlide(1), 5000);
  }
  if (prevButton && nextButton) {
    prevButton.addEventListener("click", () => moveSlide(-1));
    nextButton.addEventListener("click", () => moveSlide(1));
  }
  resetAutoSlide();

  // 绑定各个按钮点击滚动到对应区域
  const introButton = document.getElementById("intro-button");
  if (introButton) {
    introButton.addEventListener("click", () => {
      const introSection = document.querySelector('[data-section="intro"]');
      if (introSection) fastScrollTo(introSection.offsetTop, 500);
    });
  }
  const artButton = document.getElementById("art-button");
  if (artButton) {
    artButton.addEventListener("click", () => {
      const artSection = document.querySelector('[data-section="ex"]');
      if (artSection) fastScrollTo(artSection.offsetTop, 500);
    });
  }
  const gameButton = document.getElementById("game-button");
  if (gameButton) {
    gameButton.addEventListener("click", () => {
      const gameSection = document.querySelector('[data-section="game"]');
      if (gameSection) fastScrollTo(gameSection.offsetTop, 500);
    });
  }

  // 音乐开关
  const musicButton = document.getElementById("music-toggle");
  const backgroundMusic = document.getElementById("background-music");
  function tryAutoPlay() {
    if (!backgroundMusic) return;
    backgroundMusic.volume = 0.1;
    backgroundMusic.play().then(() => {
      console.log("Music auto-playing.");
    }).catch(err => {
      console.warn("Autoplay blocked. Waiting for user interaction.");
    });
  }
  function enableMusicOnUserInteraction() {
    backgroundMusic.play().then(() => {
      console.log("Music started after user interaction.");
    }).catch(err => {
      console.warn("User interaction still required.");
    });
    document.removeEventListener("click", enableMusicOnUserInteraction);
  }
  tryAutoPlay();
  document.addEventListener("click", enableMusicOnUserInteraction);

  if (musicButton && backgroundMusic) {
    musicButton.addEventListener("click", () => {
      if (backgroundMusic.paused) {
        backgroundMusic.play();
        musicButton.textContent = "🔊";
      } else {
        backgroundMusic.pause();
        musicButton.textContent = "🔇";
      }
    });
  }

  // 星星背景
  const starContainer = document.querySelector(".star-container");
  function createStars(count) {
    for (let i = 0; i < count; i++) {
      let star = document.createElement("div");
      star.classList.add("star");
      star.style.left = `${Math.random() * 100}vw`;
      star.style.top = `${Math.random() * 100}vh`;
      star.style.animationDelay = `${Math.random() * 5}s`;
      starContainer.appendChild(star);
    }
  }
  createStars(30);

  // Art slider
  const artSlides = document.querySelectorAll(".art-slide");
  let currentArtIndex = 0;
  const artLeft = document.getElementById("art-left");
  const artRight = document.getElementById("art-right");
  const creators = {
    "images/1.jpg": "Creator: Me",
    "images/1.png": "Creator: 猫型めめこ",
    "images/-min.png": "Creator: 猫型めめこ",
    "images/2.jpg": "Creator: 猫型めめこ",
    "images/AnyConv.com__Mcjxy69J.jpg": "Creator: 猫型めめこ",
    "images/c703f0b2fe754f77.jpg": "Creator: 猫型めめこ",
    "images/HappyBirthday.png": "Creator: ハッカ"
  };
  function showArtSlide(index) {
    artSlides.forEach((slide, i) => slide.classList.toggle("active", i === index));
    let imgSrc = artSlides[index].getAttribute("src");
    const creatorText = document.getElementById("art-creator");
    creatorText.textContent = creators[imgSrc] || "Creator: Unknown";
  }
  function nextArtSlide() {
    currentArtIndex = (currentArtIndex + 1) % artSlides.length;
    showArtSlide(currentArtIndex);
  }
  function prevArtSlide() {
    currentArtIndex = (currentArtIndex - 1 + artSlides.length) % artSlides.length;
    showArtSlide(currentArtIndex);
  }
  if (artRight) artRight.addEventListener("click", nextArtSlide);
  if (artLeft) artLeft.addEventListener("click", prevArtSlide);

  // 滚动触发动画
  const scrollElements = document.querySelectorAll(".scroll-trigger");
  const observerOptions = { threshold: 0.2 };
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add("animate");
    });
  }, observerOptions);
  scrollElements.forEach(el => observer.observe(el));

  // 点击时生成粒子效果
  document.addEventListener("click", function (e) {
    for (let i = 0; i < 10; i++) {
      let particle = document.createElement("div");
      particle.classList.add("particle");
      particle.style.left = `${e.pageX}px`;
      particle.style.top = `${e.pageY}px`;
      particle.style.background = `hsl(${Math.random() * 360}, 100%, 50%)`;
      particle.style.width = `${Math.random() * 8 + 4}px`;
      particle.style.height = particle.style.width;
      document.body.appendChild(particle);
      setTimeout(() => particle.remove(), 1000);
    }
  });

  // 图片放大模态框
  const modal = document.getElementById("image-modal");
  const modalImg = document.getElementById("modal-image");
  const modalCaption = document.getElementById("modal-caption");
  const zoomableImages = document.querySelectorAll(".zoomable");
  zoomableImages.forEach(img => {
    img.addEventListener("click", function () {
      modal.style.display = "block";
      modalImg.src = this.src;
      modalCaption.textContent = this.alt;
    });
  });
  const modalClose = document.querySelector(".modal-close");
  modalClose.addEventListener("click", () => modal.style.display = "none");
  window.addEventListener("click", e => {
    if (e.target === modal) modal.style.display = "none";
  });

  // 聊天机器人
  const chatbot = document.getElementById("chatbot");
  const chatbotHeader = document.getElementById("chatbot-header");
  const chatbotClose = document.getElementById("chatbot-close");
  const chatbotBody = document.getElementById("chatbot-body");
  const chatbotInput = document.getElementById("chatbot-input");
  const chatbotSend = document.getElementById("chatbot-send");
  const chatbotMinimize = document.getElementById("chatbot-minimize");

  setTimeout(() => chatbot.classList.add("show"), 2000);
  chatbotClose.addEventListener("click", () => chatbot.classList.remove("show"));
  chatbotMinimize.addEventListener("click", function () {
    if (chatbot.classList.contains("minimized")) {
      chatbot.classList.remove("minimized");
      chatbotBody.style.display = "block";
      document.getElementById("chatbot-input-area").style.display = "flex";
      chatbotMinimize.textContent = "-";
    } else {
      chatbot.classList.add("minimized");
      chatbotBody.style.display = "none";
      document.getElementById("chatbot-input-area").style.display = "none";
      chatbotMinimize.textContent = "□";
    }
  });
  
  // 发送消息函数（将输入框清空操作提前）
  async function sendChatMessage() {
    const message = chatbotInput.value.trim();
    chatbotInput.value = "";  // 立即清空输入框

    if (!message) return;
    
    // 添加用户消息
    const userMsg = document.createElement("div");
    userMsg.className = "user-message";
    userMsg.textContent = "You: " + message;
    chatbotBody.appendChild(userMsg);
    
    // 添加等待提示
    const typingIndicator = document.createElement("div");
    typingIndicator.className = "typing";
    typingIndicator.textContent = "Bot is thinking...";
    chatbotBody.appendChild(typingIndicator);
    chatbotBody.scrollTop = chatbotBody.scrollHeight;
    
    try {
      const response = await fetch('http://localhost:3001/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messages: [
            {
              role: "user",
              content: message
            }
          ]
        })
      });
      
      const data = await response.json();
      chatbotBody.removeChild(typingIndicator);
      
      if (data.success) {
        const botMsg = document.createElement("div");
        botMsg.className = "bot-message";
        botMsg.textContent = "AI: " + data.reply;
        chatbotBody.appendChild(botMsg);
      } else {
        const errorMsg = document.createElement("div");
        errorMsg.className = "error-message";
        errorMsg.textContent = "AI: I cannot reply now, please try again later.";
        chatbotBody.appendChild(errorMsg);
      }
    } catch (error) {
      chatbotBody.removeChild(typingIndicator);
      const errorMsg = document.createElement("div");
      errorMsg.className = "error-message";
      errorMsg.textContent = "AI: server connection fail.";
      chatbotBody.appendChild(errorMsg);
    }
    
    chatbotBody.scrollTop = chatbotBody.scrollHeight;
  }
  
  // 绑定点击发送消息事件
  chatbotSend.addEventListener("click", sendChatMessage);
  
  // 绑定回车发送消息事件
  chatbotInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault();
      sendChatMessage();
    }
  });

  // 在消息显示中添加语言标识
  function createMessageElement(message, lang) {
    const langFlags = {
      en: '🇺🇸',
      zh: '🇨🇳', 
      ja: '🇯🇵'
    };

    const msgEl = document.createElement('div');
    msgEl.className = `message ${lang}`;
    msgEl.innerHTML = `
      <div class="lang-flag">${langFlags[lang] || '🌐'}</div>
      <div class="content">${message}</div>
    `;
    return msgEl;
  }

  // 修改消息处理部分
  async function handleUserMessage(message) {
    // 添加用户消息
    const userMsg = createMessageElement(message, 'user');
    userMsg.querySelector('.content').textContent = message;
    chatbotBody.appendChild(userMsg);

    // 添加等待动画
    const typingIndicator = document.createElement('div');
    typingIndicator.className = 'typing';
    typingIndicator.innerHTML = `
      <div class="dot"></div>
      <div class="dot"></div>
      <div class="dot"></div>
    `;
    chatbotBody.appendChild(typingIndicator);
    chatbotBody.scrollTop = chatbotBody.scrollHeight;

    try {
      const response = await fetch('http://localhost:3001/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{ role: "user", content: message }]
        })
      });

      const data = await response.json();
      chatbotBody.removeChild(typingIndicator);

      if (data.success) {
        const botMsg = createMessageElement(data.reply, data.detected_lang);
        botMsg.classList.add('bot-message');
        chatbotBody.appendChild(botMsg);
      } else {
        const errorMsg = createMessageElement(`⚠️ ${data.details}`, 'error');
        chatbotBody.appendChild(errorMsg);
      }
    } catch (error) {
      chatbotBody.removeChild(typingIndicator);
      const errorMsg = createMessageElement('⚠️ 网络连接失败，请检查网络', 'error');
      chatbotBody.appendChild(errorMsg);
    }
    
    chatbotBody.scrollTop = chatbotBody.scrollHeight;
  }

  // 动态流动线条（canvas）
  const canvas = document.getElementById("dynamic-lines");
  const ctx = canvas.getContext("2d");
  let lines = [];
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  function initLines() {
    lines = [];
    for (let i = 0; i < 20; i++) {
      lines.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        xSpeed: Math.random() * 0.5 + 0.2,
        ySpeed: Math.random() * 0.5 + 0.2,
        length: Math.random() * 80 + 20,
        angle: Math.random() * Math.PI * 2
      });
    }
  }
  function animateLines() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    lines.forEach(line => {
      const x2 = line.x + Math.cos(line.angle) * line.length;
      const y2 = line.y + Math.sin(line.angle) * line.length;
      ctx.strokeStyle = "rgba(0, 200, 255, 0.5)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(line.x, line.y);
      ctx.lineTo(x2, y2);
      ctx.stroke();
      line.x += line.xSpeed;
      line.y += line.ySpeed;
      if (line.x > canvas.width || line.y > canvas.height) {
        line.x = Math.random() * canvas.width;
        line.y = 0;
      }
    });
    requestAnimationFrame(animateLines);
  }
  initLines();
  animateLines();
});
