document.addEventListener("DOMContentLoaded", function () {
  // 游戏相关变量
  let scene, camera, renderer, controls;
  let enemies = [];
  let bulletPickups = []; // 子弹拾取物数组
  let score = 0, health = 100;
  // 子弹系统变量
  const magazineCapacity = 30;
  let currentAmmo = magazineCapacity;
  let reserveAmmo = 0; // 备用子弹
  let gameStarted = false;
  // 鼠标灵敏度（建议初始值 0.3，范围 0.1~2）
  let mouseSensitivity = 0.3;
  // 限制玩家在地面区域内（例如 x 和 z 坐标范围 -10 到 10）
  const boundary = { minX: -10, maxX: 10, minZ: -10, maxZ: 10 };
  let isFullScreen = false;
  // 控制 pointerlockchange 事件是否处理状态变化（重置期间临时禁用）
  let allowPointerLockChange = true;

  // ------------------ 限制玩家离开地面区域 ------------------
  function clampPlayerPosition() {
    if (camera.position.x < boundary.minX) camera.position.x = boundary.minX;
    if (camera.position.x > boundary.maxX) camera.position.x = boundary.maxX;
    if (camera.position.z < boundary.minZ) camera.position.z = boundary.minZ;
    if (camera.position.z > boundary.maxZ) camera.position.z = boundary.maxZ;
    camera.position.y = 1.6;
  }

  // 更新 HUD：分数、血量以及弹药显示
  function updateHUD() {
    const scoreEl = document.getElementById("score");
    const healthEl = document.getElementById("health");
    const ammoCountEl = document.getElementById("ammo-count");
    if (scoreEl) scoreEl.textContent = score;
    if (healthEl) healthEl.textContent = health;
    if (ammoCountEl) ammoCountEl.textContent = `${currentAmmo}/${magazineCapacity}`;
  }

  // 显示游戏结束界面
  function showGameOver() {
    console.log("Game Over, showing game over page");
    gameStarted = false;
    controls.unlock();
    const gameOverEl = document.getElementById("game-over");
    if (gameOverEl) {
      document.getElementById("final-score").textContent = score;
      gameOverEl.style.display = "block";
    }
  }

  function showVictory() {
    alert("Victory! You reached 50 points!");
    showGameOver();
  }

  function gameOver() {
    showGameOver();
  }

  // 重置游戏状态，供“Play Again”使用
  // 修改：不直接调用 controls.lock()，而是显示“Start Game”按钮，由玩家点击后重新获取鼠标控制权
  function resetGame() {
    console.log("resetGame() being use");
    // 禁用 pointerlockchange 监听处理
    allowPointerLockChange = false;

    score = 0;
    health = 100;
    currentAmmo = magazineCapacity;
    reserveAmmo = 0;
    updateHUD();

    // 清除场景中敌人和子弹拾取物
    enemies.forEach(enemy => scene.remove(enemy));
    enemies = [];
    bulletPickups.forEach(pickup => scene.remove(pickup));
    bulletPickups = [];

    // 隐藏游戏结束界面
    const gameOverEl = document.getElementById("game-over");
    if (gameOverEl) {
      gameOverEl.style.display = "none";
    }

    // 重置摄像机位置与旋转
    camera.position.set(0, 1.6, 0);
    let pitchObject = controls.getObject().children[0];
    pitchObject.rotation.x = 0;
    controls.getObject().rotation.y = 0;

    // 显示“Start Game”按钮，由玩家点击后重新获取鼠标控制权
    const startGameBtn = document.getElementById("start-game");
    if (startGameBtn) {
      startGameBtn.style.display = "block";
      console.log("show Start Game button");
    } else {
      console.error(" start-game button can't find");
    }
    
    // 延迟重新启用 pointerlockchange 监听处理
    setTimeout(() => { allowPointerLockChange = true; }, 500);
  }

  function initGame() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, 800 / 600, 0.1, 1000);
    renderer = new THREE.WebGLRenderer({ antialias: true });

    const gameContainer = document.getElementById("game-container");
    gameContainer.appendChild(renderer.domElement);
    renderer.setSize(800, 600);
    renderer.domElement.style.zIndex = 0;

    // 创建十字准星
    const crosshair = document.createElement("div");
    crosshair.id = "crosshair";
    crosshair.style.position = "absolute";
    crosshair.style.top = "50%";
    crosshair.style.left = "50%";
    crosshair.style.transform = "translate(-50%, -50%)";
    crosshair.style.width = "10px";
    crosshair.style.height = "10px";
    crosshair.style.borderRadius = "50%";
    crosshair.style.backgroundColor = "white";
    crosshair.style.pointerEvents = "none";
    gameContainer.appendChild(crosshair);

    // 环境光
    const ambientLight = new THREE.AmbientLight(0x404040);
    scene.add(ambientLight);

    // 地面
    const groundGeometry = new THREE.PlaneGeometry(20, 20);
    const groundMaterial = new THREE.MeshPhongMaterial({ color: 0x00aaff });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    scene.add(ground);

    camera.position.set(0, 1.6, 0);

    controls = new THREE.PointerLockControls(camera, renderer.domElement);
    // 监听鼠标移动，更新内部对象旋转
    controls.domElement.addEventListener("mousemove", function (e) {
      if (!controls.isLocked) return;
      const movementX = e.movementX || 0;
      const movementY = e.movementY || 0;
      controls.getObject().rotation.y -= movementX * mouseSensitivity * 0.0015;
      let pitchObject = controls.getObject().children[0];
      pitchObject.rotation.x -= movementY * mouseSensitivity * 0.0015;
      pitchObject.rotation.x = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, pitchObject.rotation.x));
    });

    // 鼠标灵敏度调节（若存在对应的 slider 与 value 显示）
    const sensitivitySlider = document.getElementById("sensitivity-slider");
    const sensitivityValue = document.getElementById("sensitivity-value");
    if (sensitivitySlider) {
      sensitivitySlider.addEventListener("input", function () {
        mouseSensitivity = parseFloat(sensitivitySlider.value);
        if (sensitivityValue) {
          sensitivityValue.textContent = sensitivitySlider.value;
        }
      });
    }

    // 隐藏加载提示
    document.getElementById("loading").style.display = "none";

    updateHUD();
  }

  // 键盘控制
  const keyStates = { w: false, s: false, a: false, d: false };
  document.addEventListener("keydown", e => {
    const key = e.key.toLowerCase();
    if (["w", "s", "a", "d"].includes(key)) keyStates[key] = true;
    if (key === "f") {
      const gameContainer = document.getElementById("game-container");
      if (!isFullScreen && gameContainer.requestFullscreen) {
        gameContainer.requestFullscreen();
        isFullScreen = true;
      }
    }
    if (e.key === "Escape") {
      if (isFullScreen && document.fullscreenElement) {
        document.exitFullscreen();
        isFullScreen = false;
      }
    }
    if (key === "e") {
      pickupBullet();
    }
    if (key === "r") {
      reload();
    }
  });
  document.addEventListener("keyup", e => {
    const key = e.key.toLowerCase();
    if (["w", "s", "a", "d"].includes(key)) keyStates[key] = false;
  });

  function updateMovement() {
    const delta = 0.1;
    if (keyStates.w) controls.moveForward(delta);
    if (keyStates.s) controls.moveForward(-delta);
    if (keyStates.a) controls.moveRight(-delta);
    if (keyStates.d) controls.moveRight(delta);
    clampPlayerPosition();
  }

  // ---------------------- 敌人相关代码 ----------------------
  function createHealthLabel(health) {
    const canvas = document.createElement("canvas");
    canvas.width = 64;
    canvas.height = 32;
    const context = canvas.getContext("2d");
    context.font = "20px Arial";
    context.fillStyle = "white";
    context.textAlign = "center";
    context.fillText(health, canvas.width / 2, canvas.height / 2);
    const texture = new THREE.CanvasTexture(canvas);
    const material = new THREE.SpriteMaterial({ map: texture });
    const sprite = new THREE.Sprite(material);
    sprite.scale.set(2, 1, 1);
    return sprite;
  }

  function updateEnemyHealthLabel(enemy) {
    if (!enemy.healthLabel) return;
    const canvas = enemy.healthLabel.material.map.image;
    const context = canvas.getContext("2d");
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.font = "20px Arial";
    context.fillStyle = "white";
    context.textAlign = "center";
    context.fillText(enemy.health, canvas.width / 2, canvas.height / 2);
    enemy.healthLabel.material.map.needsUpdate = true;
  }

  function spawnEnemy() {
    if (!gameStarted) return;
    const geometry = new THREE.SphereGeometry(0.5);
    const material = new THREE.MeshBasicMaterial({ color: 0xff0000 });
    const enemy = new THREE.Mesh(geometry, material);
    enemy.position.set(
      Math.random() * 18 - 9,
      0.5,
      Math.random() * 18 - 9
    );
    enemy.health = 100;
    enemy.healthLabel = createHealthLabel(enemy.health);
    enemy.add(enemy.healthLabel);
    enemy.healthLabel.position.set(0, 1, 0);
    // 随机左右移动：1 表示向右，-1 表示向左
    enemy.moveDir = Math.random() < 0.5 ? -1 : 1;
    scene.add(enemy);
    enemies.push(enemy);
  }
  setInterval(spawnEnemy, 5000);

  function checkCollisions() {
    enemies.forEach((enemy, index) => {
      if (camera.position.distanceTo(enemy.position) < 1) {
        health -= 10;
        scene.remove(enemy);
        enemies.splice(index, 1);
        updateHUD();
        if (health <= 0) gameOver();
      }
    });
  }

  // 敌人固定射击，每 250ms 检测一次，如果玩家在射程内则发射固定伤害
  function enemyAttack() {
    if (!gameStarted) return;
    enemies.forEach(enemy => {
      // 增加移动速度和幅度：乘以 0.5，使移动更明显
      enemy.position.x += (Math.random() - 0.5) * 0.5 * enemy.moveDir;
      if (enemy.position.x < boundary.minX || enemy.position.x > boundary.maxX) {
        enemy.moveDir *= -1;
      }
      
      const enemyToPlayer = new THREE.Vector3().subVectors(camera.position, enemy.position).normalize();
      const distance = enemy.position.distanceTo(camera.position);
      
      let playerMove = new THREE.Vector3();
      if (keyStates.w) playerMove.z -= 1;
      if (keyStates.s) playerMove.z += 1;
      if (keyStates.a) playerMove.x -= 1;
      if (keyStates.d) playerMove.x += 1;
      playerMove.normalize();
      let dot = playerMove.dot(enemyToPlayer);
      
      // 如果玩家在 10 内
      if (distance < 5) {
        // 如果玩家没有有效躲避，则每次射击固定伤害 5
        if (playerMove.length() === 0 || dot > 0.5) {
          const damage = 2;
          health -= damage;
          updateHUD();
          if (health <= 0) gameOver();
          showEnemyAttackLine(enemy);
        } else {
          console.log("Player dodged the attack!");
        }
      }
    });
  }
  setInterval(enemyAttack, 250);

  function showEnemyAttackLine(enemy) {
    const material = new THREE.LineBasicMaterial({ color: 0xff0000 });
    const points = [];
    points.push(enemy.position.clone());
    points.push(camera.position.clone());
    const geometry = new THREE.BufferGeometry().setFromPoints(points);
    const line = new THREE.Line(geometry, material);
    scene.add(line);
    setTimeout(() => scene.remove(line), 100);
  }

  // ---------------------- 子弹系统 ----------------------
  function shootBullet() {
    if (currentAmmo <= 0) return;
    currentAmmo--;
    updateHUD();
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
    const intersects = raycaster.intersectObjects(enemies);
    if (intersects.length > 0) {
      const enemy = intersects[0].object;
      // 玩家攻击伤害从 50 改为 30
      enemy.health -= 30;
      updateEnemyHealthLabel(enemy);
      if (enemy.health <= 0) {
        score++;
        updateHUD();
        scene.remove(enemy);
        enemies.splice(enemies.indexOf(enemy), 1);
        if (score >= 30) showVictory();
      }
    }
  }

  function reload() {
    const needed = magazineCapacity - currentAmmo;
    if (needed > 0 && reserveAmmo > 0) {
      if (reserveAmmo >= needed) {
        currentAmmo += needed;
        reserveAmmo -= needed;
      } else {
        currentAmmo += reserveAmmo;
        reserveAmmo = 0;
      }
      updateHUD();
    }
  }

  function spawnBulletPickup() {
    if (!gameStarted) return;
    const geometry = new THREE.SphereGeometry(0.3);
    const material = new THREE.MeshBasicMaterial({ color: 0x0000ff });
    const pickup = new THREE.Mesh(geometry, material);
    pickup.position.set(
      Math.random() * 18 - 9,
      0.3,
      Math.random() * 18 - 9
    );
    scene.add(pickup);
    bulletPickups.push(pickup);
  }
  setInterval(spawnBulletPickup, 10000);

  function pickupBullet() {
    for (let i = bulletPickups.length - 1; i >= 0; i--) {
      const pickup = bulletPickups[i];
      if (camera.position.distanceTo(pickup.position) < 3) {
        reserveAmmo += 10;
        updateHUD();
        scene.remove(pickup);
        bulletPickups.splice(i, 1);
      }
    }
  }

  // ---------------------- 射击与瞄准 ----------------------
  document.addEventListener("contextmenu", e => e.preventDefault());
  document.addEventListener("mousedown", e => {
    if (!gameStarted) return;
    if (e.button === 0) {
      shootBullet();
    } else if (e.button === 2) {
      enterAimMode();
    }
  });
  document.addEventListener("mouseup", e => {
    if (e.button === 2) exitAimMode();
  });

  function enterAimMode() {
    camera.fov = 40;
    camera.updateProjectionMatrix();
  }
  function exitAimMode() {
    camera.fov = 75;
    camera.updateProjectionMatrix();
  }

  // PointerLock 状态监听
  document.addEventListener("pointerlockchange", () => {
    if (!allowPointerLockChange) return;
    if (document.pointerLockElement !== renderer.domElement && gameStarted) {
      gameStarted = false;
      document.getElementById("start-game").style.display = "block";
      console.log("PointerLock loss，show Start Game button");
    }
  });

  function resetGame() {
    console.log("resetGame() using");
    // 禁用 pointerlockchange 监听处理
    allowPointerLockChange = false;

    score = 0;
    health = 100;
    currentAmmo = magazineCapacity;
    reserveAmmo = 0;
    updateHUD();

    // 清除场景中敌人和子弹拾取物
    enemies.forEach(enemy => scene.remove(enemy));
    enemies = [];
    bulletPickups.forEach(pickup => scene.remove(pickup));
    bulletPickups = [];

    // 隐藏游戏结束界面
    const gameOverEl = document.getElementById("game-over");
    if (gameOverEl) {
      gameOverEl.style.display = "none";
    }

    // 重置摄像机位置与旋转
    camera.position.set(0, 1.6, 0);
    let pitchObject = controls.getObject().children[0];
    pitchObject.rotation.x = 0;
    controls.getObject().rotation.y = 0;

    // 显示 Start Game 按钮
    const startGameBtn = document.getElementById("start-game");
    if (startGameBtn) {
      startGameBtn.style.display = "block";
      console.log("show Start Game button");
      // 确保按钮可见
      startGameBtn.style.visibility = "visible";
      startGameBtn.disabled = false;
    }
    
    // 确保退出指针锁定
    document.exitPointerLock();
    controls.unlock();
    gameStarted = false;

    // 延迟重新启用 pointerlockchange 监听处理
    setTimeout(() => { allowPointerLockChange = true; }, 500);
  }function resetGame() {
    console.log("resetGame() 被调用");
    
    // 重置游戏状态
    score = 0;
    health = 100;
    currentAmmo = magazineCapacity;
    reserveAmmo = 0;
    updateHUD();
  
    // 清除所有游戏对象
    enemies.forEach(enemy => scene.remove(enemy));
    enemies = [];
    bulletPickups.forEach(pickup => scene.remove(pickup));
    bulletPickups = [];
  
    // 重置摄像机
    camera.position.set(0, 1.6, 0);
    camera.rotation.set(0, 0, 0);
    
    // 重置控制系统的旋转
    if (controls && controls.getObject()) {
      controls.getObject().rotation.set(0, 0, 0);
    }
  
    // 显示Start按钮，隐藏Game Over界面
    document.getElementById("start-game").style.display = "block";
    document.getElementById("game-over").style.display = "none";
  
    // 强制退出指针锁定
    document.exitPointerLock();
    controls.unlock();
    gameStarted = false;
  }

  // 游戏主循环
  function gameLoop() {
    requestAnimationFrame(gameLoop);
    if (gameStarted) {
      updateMovement();
      checkCollisions();
      renderer.render(scene, camera);
    }
  }

  // 游戏主循环
  function gameLoop() {
    requestAnimationFrame(gameLoop);
    if (gameStarted) {
      updateMovement();
      checkCollisions();
      renderer.render(scene, camera);
    }
  }

  initGame();
  gameLoop();

  // “Start Game”按钮点击事件（用于首次进入和重置后重新获取鼠标控制权）
  document.getElementById("start-game").addEventListener("click", function() {
    console.log("Game Start!");
    
    // 隐藏开始按钮
    this.style.display = "none";
    
    // 初始化敌人
    for(let i = 0; i < 3; i++) spawnEnemy();
    
    // 启动指针锁定
    controls.lock();
    gameStarted = true;
  });
  

  // “Play Again”按钮点击事件，点击后重置游戏并显示“Start Game”按钮
  document.getElementById("restart").addEventListener("click", function() {
    console.log("Click Play Again");
    
    // 重置游戏但不显示开始按钮（由resetGame处理）
    resetGame();
    
    // 这里不需要额外隐藏game-over，resetGame已经处理
  });
});
