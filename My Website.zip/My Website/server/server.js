require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const HF_API_KEY = process.env.HUGGINGFACEHUB_API_TOKEN;
const MODEL_ENDPOINT = "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2";

// 增强版语言检测
const detectLanguage = (text) => {
  // 中文检测（简繁汉字、标点）
  const chineseRegex = /[\u4E00-\u9FFF\u3400-\u4DBF\u3000-\u303F\uFF00-\uFFEF]/;
  // 日文检测（平假名、片假名、日文汉字）
  const japaneseRegex = /[\u3040-\u309F\u30A0-\u30FF\u4E00-\u9FFF\u3400-\u4DBF]/;
  
  const charCount = {
    zh: (text.match(chineseRegex) || []).length,
    ja: (text.match(japaneseRegex) || []).length
  };

  if (charCount.zh > charCount.ja) return 'zh';
  if (charCount.ja > 3) return 'ja';
  return 'en'; // 默认英语
};

// 优化后的提示词模板
const PROMPT_TEMPLATES = {
  en: (text) => `Respond in English. Keep it under 3 sentences. Context: ${text}`,
  zh: (text) => `用简体中文回答，保持简洁（最多三句话）。问题：${text}`,
  ja: (text) => `日本語で簡潔に答えてください（3文以内）。質問：${text}`
};

app.post('/api/chat', async (req, res) => {
  try {
    const lastMessage = req.body.messages.slice(-1)[0];
    const userText = lastMessage.content.trim();
    const lang = detectLanguage(userText);

    const response = await axios.post(
      MODEL_ENDPOINT,
      {
        inputs: PROMPT_TEMPLATES[lang](userText),
        parameters: {
          max_new_tokens: 150,
          temperature: 0.7,
          repetition_penalty: 1.2
        }
      },
      {
        headers: {
          Authorization: `Bearer ${HF_API_KEY}`,
          'Content-Type': 'application/json'
        },
        timeout: 15000 // 15秒超时
      }
    );

    // 清理模型输出
    const rawText = response.data[0]?.generated_text || "";
    const cleanText = rawText
      .replace(PROMPT_TEMPLATES[lang](""), "") // 移除提示词
      .trim()
      .replace(/[\n]+/g, " ");

    res.json({ 
      success: true,
      reply: cleanText,
      detected_lang: lang
    });

  } catch (error) {
    console.error('API Error:', error);
    const status = error.response?.status || 500;
    const message = error.response?.data?.error || "cannot connect to server, please try again later.";
    
    res.status(status).json({
      success: false,
      error: "AI error",
      details: `${message} (Error: ${status})`
    });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`✅ Start: http://localhost:${PORT}`);
});